###########
sim_baddata.R
###########

Simulates 1 bad data set under scenario 1. The bad data set gives NA for the covariance obtained using flexsurvspline when using 3 internal knots. Inverting the hessian gives a negative variance.

Fitting the flexsurv model durectly using optim instead of flexsurvspline gives a variance-covariance matrix which seems OK, at least in terms of giving non-negative variances. 

###########
scenario1_gooddata.RData
###########

The good data set generated under scenario 1. 
Flexsurvspline gives a covariance matrix. However, optim gives different variances. 

I noticed that with the same simulated data set I sometimes got NA for the varcov matrix from flexsurvspline and other times it worked. This is weird. Maybe something to do with random choice of initial values? 

###########
scenario3_gooddata.RData
###########

The bad data set generated under scenario 3. 
#F;exsurvspline does not give a covariance matrix, though inverting the Hessian directly seem OK because all the variances it gives are positive. Using optim works and gives the same set of variances. 

############
optim_test.R
############

Fits a flex surv model with 3 internal knots 'by hand', i.e. by defining the likelihood and optimizing using 'optim'.

This outputs 'optim.fit', which is the usual results from optim, and 'varcov.myhess', which is the variance-covarianc matrix found using fdHess after optim.

I have used method="Nelder-Mead" because "BFGS" was sometimes giving error messages relating to finite-difference values. 

############
sim_data.R
############

Simulates data according to scenarios 1-4. 

