

#knot positions for 3 internal knots
myknots=quantile(log(t[d==1]),c(0,0.25,0.5,0.75,1))

#spline basis function

v=function(t,kmin,kmax,k){
  (pmax(log(t)-k,0))^3-((kmax-k)/(kmax-kmin))*(pmax(log(t)-kmin,0))^3-
    ((k-kmin)/(kmax-kmin))*(pmax(log(t)-kmax,0))^3
}

#derivative of spline basis function (used in the hazard function)

v.deriv=function(t,kmin,kmax,k){
  (3/t)*(pmax((log(t)-k),0))^2-((kmax-k)/(kmax-kmin))*(3/t)*(pmax((log(t)-kmin),0))^2-
    ((k-kmin)/(kmax-kmin))*(3/t)*(pmax((log(t)-kmax),0))^2
}

#likelihood function

loglik.3knot=function(params){
  gamma0=params[1]
  gamma1=params[2]
  gamma2=params[3]
  gamma3=params[4]
  gamma4=params[5]
  
  
  loglog.survfunc=gamma0+gamma1*log(t)+
    gamma2*sapply(t,FUN=function(t)v(t,myknots[1],myknots[5],myknots[2]))+
    gamma3*sapply(t,FUN=function(t)v(t,myknots[1],myknots[5],myknots[3]))+
    gamma4*sapply(t,FUN=function(t)v(t,myknots[1],myknots[5],myknots[4]))
  
  survfunc=exp(-exp(loglog.survfunc))
  
  hazfunc=(gamma1*(1/t)+
             gamma2*sapply(t,FUN=function(t)v.deriv(t,myknots[1],myknots[5],myknots[2]))+
             gamma3*sapply(t,FUN=function(t)v.deriv(t,myknots[1],myknots[5],myknots[3]))+
             gamma4*sapply(t,FUN=function(t)v.deriv(t,myknots[1],myknots[5],myknots[4])))*
    exp(gamma0+gamma1*log(t)+
          gamma2*sapply(t,FUN=function(t)v(t,myknots[1],myknots[5],myknots[2]))+
          gamma3*sapply(t,FUN=function(t)v(t,myknots[1],myknots[5],myknots[3]))+
          gamma4*sapply(t,FUN=function(t)v(t,myknots[1],myknots[5],myknots[4]))) 
  
  #negative loglik
   -sum((1-d)*log(survfunc)+d*log(hazfunc*survfunc))
}

optim.fit=optim(start.values,loglik.3knot,method="Nelder-Mead",hessian=F)

library(nlme)

myhess=fdHess(start.values,loglik.3knot)

varcov.myhess=solve(myhess$Hessian)
