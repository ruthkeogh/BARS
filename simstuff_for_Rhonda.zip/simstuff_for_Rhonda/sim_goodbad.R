
setwd("H:/CF_UK_lifeexp/BARS_sim")

#------------------------
#generate seeds (as in Ruth's simulations so far)
#------------------------

nsim=1000
set.seed=3010
seeds=sample(1:1e+7,size=nsim,replace=F)

#-----------------------
#Scenario 1: a 'good' data set
#-----------------------

#set seed
sim=1
set.seed=seeds[sim]

#simulate data under scenario 1
scenario=1
source("./sim_data.R")
mydata=data.frame(t,d)
save(mydata,file="./simstuff_for_Rhonda/scenario1_gooddata.RData")

#run flexsurv on this data set with 0 knots (weibull)
#this works fine 
scen1.flexmod.0knot=flexsurvspline(Surv(t,d)~1,data=mydata,scale="hazard",k=0)
scen1.flexmod.0knot$cov

#run flexsurv with 4 internal knots 
#the covariance is OK
scen1.flexmod.3knot=flexsurvspline(Surv(t,d)~1,data=mydata,scale="hazard",timescale="log",k=3)
scen1.flexmod.3knot$cov

#fit a flexsurv model with 3 knots using optim
start.values=scen1.flexmod.3knot$coefficients
source("./optim_test.R")

optim.fit$par #parameter estimates
varcov.myhess #var-cov matrix
diag(varcov.myhess) #variances
#these variances differ from those found using flexsurv

#-----------------------
#Scenario 3: a 'bad' data set
#-----------------------

#set seed
sim=1
set.seed=seeds[sim]

#simulate data under scenario 1
scenario=3
source("./sim_data.R")
mydata=data.frame(t,d)
save(mydata,file="./simstuff_for_Rhonda/scenario3_baddata.RData")

#run flexsurv on this data set with 0 knots (weibull)
#this works fine 
scen3.flexmod.0knot=flexsurvspline(Surv(t,d)~1,data=mydata,scale="hazard",k=0)
scen3.flexmod.0knot$cov

#run flexsurv with 4 internal knots 
#the covariance is NA
#BUT inverting the hessian does not give any negative variances
scen3.flexmod.3knot=flexsurvspline(Surv(t,d)~1,data=mydata,scale="hazard",timescale="log",k=3)
scen3.flexmod.3knot$cov
solve(scen3.flexmod.3knot$opt$hessian)
diag(solve(scen3.flexmod.3knot$opt$hessian))

#fit a flexsurv model with 3 knots using optim
start.values=scen3.flexmod.3knot$coefficients
source("./optim_test.R")

optim.fit$par #parameter estimates
varcov.myhess #var-cov matrix
diag(varcov.myhess) #variances
#the variances here are the as given by diag(solve(scen3.flexmod.3knot$opt$hessian))

